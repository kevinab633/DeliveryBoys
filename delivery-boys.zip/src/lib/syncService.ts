import { v4 as uuidv4 } from 'uuid';
import supabase from './supabase';
import { Order, OrderStatus, RiderProfile } from './types';
import { useOrderStore } from '../stores/orderStore';
import { useAuthStore } from '../stores/authStore';
import { fireBrowserNotification } from './browserNotify';

// Unique client instance identifier to avoid handling self-broadcast loops
export const CLIENT_ID = uuidv4();

const CHANNEL_NAME = 'delivery_boys_live_sync';
const LOCAL_CHANNEL_NAME = 'delivery_boys_local_channel';

// Type definitions for broadcast events
export type SyncEvent =
  | { type: 'ORDER_CREATED'; senderId: string; order: Order }
  | {
      type: 'ORDER_ACCEPTED';
      senderId: string;
      orderId: string;
      riderId: string;
      riderName: string;
      riderPhone?: string;
      acceptedAt: number;
    }
  | {
      type: 'ORDER_STATUS_CHANGED';
      senderId: string;
      orderId: string;
      status: OrderStatus;
      timestamp: number;
    }
  | {
      type: 'RIDER_LOCATION_UPDATED';
      senderId: string;
      orderId: string;
      lat: number;
      lng: number;
      riderId: string;
    }
  | {
      type: 'ORDER_CANCELLED';
      senderId: string;
      orderId: string;
      cancelReason?: string;
    }
  | {
      type: 'ORDER_DISPATCH_EXPANDED';
      senderId: string;
      orderId: string;
      dispatchedTo: string[];
    }
  | {
      type: 'RIDER_PRESENCE';
      senderId: string;
      rider: RiderProfile;
    };

// Listeners for UI connection status
type ConnectionListener = (connected: boolean) => void;
const connectionListeners = new Set<ConnectionListener>();

let isConnected = false;
let broadcastChannel: BroadcastChannel | null = null;
let realtimeChannel: ReturnType<typeof supabase.channel> | null = null;
let isInitialized = false;
let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_DELAY = 30000;
let isSubscribing = false;

function setConnectionStatus(status: boolean) {
  isConnected = status;
  connectionListeners.forEach((fn) => {
    try {
      fn(status);
    } catch {
      void 0;
    }
  });
}

export function onConnectionChange(fn: ConnectionListener): () => void {
  connectionListeners.add(fn);
  fn(isConnected);
  return () => {
    connectionListeners.delete(fn);
  };
}

export function getSyncStatus(): boolean {
  return isConnected;
}

// Convert database row to app Order object
export function rowToOrder(row: any): Order {
  const pickupData = typeof row.pickup === 'object' && row.pickup ? row.pickup : {};
  const dropoffData = typeof row.dropoff === 'object' && row.dropoff ? row.dropoff : {};

  return {
    id: row.id,
    customerId: row.customer_id || 'cust-anon',
    customerName: pickupData.customerName || 'Customer',
    customerPhone: pickupData.customerPhone || '',
    pickup: {
      lat: typeof pickupData.lat === 'number' ? pickupData.lat : 5.6037,
      lng: typeof pickupData.lng === 'number' ? pickupData.lng : -0.187,
      address: pickupData.address || 'Accra',
    },
    dropoff: {
      lat: typeof dropoffData.lat === 'number' ? dropoffData.lat : 5.556,
      lng: typeof dropoffData.lng === 'number' ? dropoffData.lng : -0.1824,
      address: dropoffData.address || 'Accra',
    },
    distance: typeof pickupData.distance === 'number' ? pickupData.distance : 5.0,
    price: Number(row.price) || 25,
    status: (row.status as OrderStatus) || 'pending',
    vehicleType: row.vehicle_type || 'motorcycle',
    packageDescription: row.package_description || 'Package delivery',
    orderType: row.order_type || 'instant',
    scheduledFor: row.scheduled_for ? Number(row.scheduled_for) : undefined,
    dispatchedTo: Array.isArray(row.dispatched_to) ? row.dispatched_to : undefined,
    riderId: row.rider_id || undefined,
    riderName: row.rider_name || undefined,
    riderLocation:
      row.rider_location && typeof row.rider_location.lat === 'number'
        ? row.rider_location
        : undefined,
    cancelReason: row.cancel_reason || undefined,
    createdAt: row.created_at ? new Date(row.created_at).getTime() : Date.now(),
    acceptedAt: pickupData.acceptedAt ? Number(pickupData.acceptedAt) : undefined,
    pickedUpAt: pickupData.pickedUpAt ? Number(pickupData.pickedUpAt) : undefined,
    deliveredAt: pickupData.deliveredAt ? Number(pickupData.deliveredAt) : undefined,
  };
}

// Convert app Order object to database row payload
export function orderToRow(order: Order): any {
  return {
    id: order.id,
    customer_id: order.customerId,
    rider_id: order.riderId || null,
    rider_name: order.riderName || null,
    status: order.status,
    pickup: {
      lat: order.pickup.lat,
      lng: order.pickup.lng,
      address: order.pickup.address,
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      distance: order.distance,
      acceptedAt: order.acceptedAt,
      pickedUpAt: order.pickedUpAt,
      deliveredAt: order.deliveredAt,
    },
    dropoff: {
      lat: order.dropoff.lat,
      lng: order.dropoff.lng,
      address: order.dropoff.address,
    },
    price: order.price,
    vehicle_type: order.vehicleType,
    package_description: order.packageDescription,
    order_type: order.orderType,
    scheduled_for: order.scheduledFor || null,
    dispatched_to: order.dispatchedTo || null,
    rider_location: order.riderLocation || null,
    cancel_reason: order.cancelReason || null,
  };
}

// ── Broadcast sender (sends via both WebSocket and local BroadcastChannel) ──
function emitSyncEvent(event: SyncEvent) {
  // 1. Send via local BroadcastChannel for zero-latency cross-tab sync
  if (broadcastChannel) {
    try {
      broadcastChannel.postMessage(event);
    } catch {
      void 0;
    }
  }

  // 2. Send via Supabase Realtime WebSocket for cross-device live sync
  if (realtimeChannel && isConnected) {
    try {
      realtimeChannel.send({
        type: 'broadcast',
        event: event.type,
        payload: event,
      });
    } catch {
      void 0;
    }
  }
}

// ── Handle incoming sync event from any peer ──
export function handleIncomingSyncEvent(event: SyncEvent) {
  if (!event || event.senderId === CLIENT_ID) return;

  const orderStore = useOrderStore.getState();
  const authStore = useAuthStore.getState();

  switch (event.type) {
    case 'ORDER_CREATED': {
      const incoming = event.order;
      if (!incoming || !incoming.id) return;
      orderStore.applyRemoteOrder(incoming);

      // If current user is an online rider, alert them with native notification
      const currentUser = authStore.user;
      if (
        currentUser &&
        currentUser.role === 'rider' &&
        (currentUser as RiderProfile).availability === 'online'
      ) {
        fireBrowserNotification(
          '🚨 Incoming Delivery Request!',
          `Pickup: ${incoming.pickup.address} · GH₵ ${incoming.price.toFixed(2)}`,
        );
      }
      break;
    }

    case 'ORDER_ACCEPTED': {
      orderStore.applyRemoteOrderAccepted(
        event.orderId,
        event.riderId,
        event.riderName,
        event.riderPhone,
        event.acceptedAt,
      );
      break;
    }

    case 'ORDER_STATUS_CHANGED': {
      orderStore.applyRemoteStatus(event.orderId, event.status, event.timestamp);
      break;
    }

    case 'RIDER_LOCATION_UPDATED': {
      orderStore.applyRemoteRiderLocation(event.orderId, event.lat, event.lng);
      // Also update the rider profile location in allUsers
      if (event.riderId) {
        authStore.applyRemoteRiderLocation(event.riderId, event.lat, event.lng);
      }
      break;
    }

    case 'ORDER_CANCELLED': {
      orderStore.applyRemoteCancel(event.orderId, event.cancelReason);
      break;
    }

    case 'ORDER_DISPATCH_EXPANDED': {
      orderStore.applyRemoteDispatchExpanded(event.orderId, event.dispatchedTo);
      break;
    }

    case 'RIDER_PRESENCE': {
      if (event.rider && event.rider.id) {
        authStore.applyRemoteRiderPresence(event.rider);
      }
      break;
    }
  }
}

// ── Public API for dispatching sync events ──
export const syncService = {
  /**
   * Broadcast a newly created order to all online riders.
   */
  broadcastNewOrder(order: Order) {
    emitSyncEvent({
      type: 'ORDER_CREATED',
      senderId: CLIENT_ID,
      order,
    });
    // Persist to Supabase database in background
    void syncService.saveOrderToDatabase(order);
  },

  /**
   * Broadcast that a rider accepted the order.
   */
  broadcastOrderAccepted(
    orderId: string,
    riderId: string,
    riderName: string,
    riderPhone?: string,
    acceptedAt = Date.now(),
  ) {
    emitSyncEvent({
      type: 'ORDER_ACCEPTED',
      senderId: CLIENT_ID,
      orderId,
      riderId,
      riderName,
      riderPhone,
      acceptedAt,
    });
    // Update Supabase database in background
    void syncService.updateOrderInDatabase(orderId, {
      status: 'accepted',
      riderId,
      riderName,
      acceptedAt,
    });
  },

  /**
   * Broadcast order status changes (picked_up, in_transit, delivered).
   */
  broadcastOrderStatus(orderId: string, status: OrderStatus, timestamp = Date.now()) {
    emitSyncEvent({
      type: 'ORDER_STATUS_CHANGED',
      senderId: CLIENT_ID,
      orderId,
      status,
      timestamp,
    });
    const updates: Partial<Order> = { status };
    if (status === 'picked_up') updates.pickedUpAt = timestamp;
    if (status === 'delivered') updates.deliveredAt = timestamp;
    void syncService.updateOrderInDatabase(orderId, updates);
  },

  /**
   * Broadcast live GPS location of the rider.
   */
  broadcastRiderLocation(orderId: string, lat: number, lng: number, riderId: string) {
    emitSyncEvent({
      type: 'RIDER_LOCATION_UPDATED',
      senderId: CLIENT_ID,
      orderId,
      lat,
      lng,
      riderId,
    });
    // Throttle database update to prevent excessive writes while keeping WebSockets 60fps
    void syncService.updateOrderInDatabase(orderId, {
      riderLocation: { lat, lng },
    });
  },

  /**
   * Broadcast order cancellation.
   */
  broadcastOrderCancelled(orderId: string, cancelReason?: string) {
    emitSyncEvent({
      type: 'ORDER_CANCELLED',
      senderId: CLIENT_ID,
      orderId,
      cancelReason,
    });
    void syncService.updateOrderInDatabase(orderId, {
      status: 'cancelled',
      cancelReason,
    });
  },

  /**
   * Broadcast widened dispatch window.
   */
  broadcastDispatchExpanded(orderId: string, dispatchedTo: string[]) {
    emitSyncEvent({
      type: 'ORDER_DISPATCH_EXPANDED',
      senderId: CLIENT_ID,
      orderId,
      dispatchedTo,
    });
    void syncService.updateOrderInDatabase(orderId, { dispatchedTo });
  },

  /**
   * Broadcast online rider presence (so customers see live moving bikes on the map).
   */
  broadcastRiderPresence(rider: RiderProfile) {
    emitSyncEvent({
      type: 'RIDER_PRESENCE',
      senderId: CLIENT_ID,
      rider,
    });
  },

  /**
   * Persist order to Supabase Postgres table.
   */
  async saveOrderToDatabase(order: Order) {
    try {
      const row = orderToRow(order);
      const { error } = await supabase.from('orders').upsert(row);
      if (error) {
        console.warn('[SyncService] DB saveOrder error:', error.message);
      }
    } catch (err) {
      console.warn('[SyncService] saveOrder failed:', err);
    }
  },

  /**
   * Update order in Supabase Postgres table.
   */
  async updateOrderInDatabase(orderId: string, updates: Partial<Order>) {
    try {
      const payload: any = { updated_at: new Date().toISOString() };
      if (updates.status) payload.status = updates.status;
      if (updates.riderId) payload.rider_id = updates.riderId;
      if (updates.riderName) payload.rider_name = updates.riderName;
      if (updates.riderLocation) payload.rider_location = updates.riderLocation;
      if (updates.cancelReason) payload.cancel_reason = updates.cancelReason;
      if (updates.dispatchedTo) payload.dispatched_to = updates.dispatchedTo;

      const { error } = await supabase.from('orders').update(payload).eq('id', orderId);
      if (error) {
        console.warn('[SyncService] DB updateOrder error:', error.message);
      }
    } catch (err) {
      console.warn('[SyncService] updateOrder failed:', err);
    }
  },

  /**
   * Fetch historical and active orders from Supabase on startup.
   */
  async fetchRemoteOrders(): Promise<Order[]> {
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) {
        console.warn('[SyncService] fetchRemoteOrders error:', error.message);
        return [];
      }
      if (!data || !Array.isArray(data)) return [];
      return data.map(rowToOrder);
    } catch (err) {
      console.warn('[SyncService] fetchRemoteOrders failed:', err);
      return [];
    }
  },

  /**
   * Internal helper to establish/re-establish Supabase Realtime channel.
   * Completely backgrounded and non-blocking; UI continues working offline or via BroadcastChannel.
   */
  connectRealtime() {
    if (isSubscribing) return;
    isSubscribing = true;

    // Clean up previous channel instance if any
    if (realtimeChannel) {
      try {
        supabase.removeChannel(realtimeChannel);
      } catch {
        /* ignore cleanup error */
      }
      realtimeChannel = null;
    }

    try {
      const channel = supabase.channel(CHANNEL_NAME, {
        config: { broadcast: { self: false } },
      });
      realtimeChannel = channel;

      const eventTypes: SyncEvent['type'][] = [
        'ORDER_CREATED',
        'ORDER_ACCEPTED',
        'ORDER_STATUS_CHANGED',
        'RIDER_LOCATION_UPDATED',
        'ORDER_CANCELLED',
        'ORDER_DISPATCH_EXPANDED',
        'RIDER_PRESENCE',
      ];

      eventTypes.forEach((eventType) => {
        channel.on('broadcast', { event: eventType }, (msg) => {
          if (msg?.payload) {
            handleIncomingSyncEvent(msg.payload as SyncEvent);
          }
        });
      });

      channel.subscribe((status) => {
        isSubscribing = false;
        if (status === 'SUBSCRIBED') {
          console.log('[SyncService] Realtime WebSocket connected');
          setConnectionStatus(true);
          reconnectAttempts = 0;
          if (reconnectTimer) {
            clearTimeout(reconnectTimer);
            reconnectTimer = null;
          }
          // Catch up remote orders in the background once connected
          void syncService.fetchRemoteOrders().then((remoteOrders) => {
            if (remoteOrders && remoteOrders.length > 0) {
              useOrderStore.getState().mergeRemoteOrders(remoteOrders);
            }
          });
        } else if (status === 'CLOSED' || status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          console.warn(`[SyncService] Realtime channel status: ${status}. Retrying in background...`);
          setConnectionStatus(false);
          syncService.scheduleReconnect();
        }
      });
    } catch (err) {
      isSubscribing = false;
      console.warn('[SyncService] Supabase channel error:', err);
      setConnectionStatus(false);
      syncService.scheduleReconnect();
    }
  },

  /**
   * Schedule automatic background reconnection with exponential backoff and jitter.
   */
  scheduleReconnect() {
    if (reconnectTimer) return;
    const baseDelay = Math.min(2000 * Math.pow(1.5, reconnectAttempts), MAX_RECONNECT_DELAY);
    const jitter = Math.random() * 1000;
    const delay = Math.round(baseDelay + jitter);
    reconnectAttempts++;

    console.log(`[SyncService] Scheduling background reconnect in ${delay}ms (attempt #${reconnectAttempts})`);
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      syncService.connectRealtime();
    }, delay);
  },

  /**
   * Initialize all realtime listeners and sync on app startup.
   * Never blocks UI rendering or execution.
   */
  init() {
    if (isInitialized) return;
    isInitialized = true;

    // 1. Initialize local cross-tab BroadcastChannel (instant zero-latency for same-browser tabs)
    if (typeof BroadcastChannel !== 'undefined') {
      try {
        broadcastChannel = new BroadcastChannel(LOCAL_CHANNEL_NAME);
        broadcastChannel.onmessage = (e) => {
          if (e.data) handleIncomingSyncEvent(e.data);
        };
      } catch {
        void 0;
      }
    }

    // 2. Initialize Supabase Realtime WebSocket in the background
    syncService.connectRealtime();

    // 3. Register browser online and visibility listeners for instant recovery on mobile
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => {
        console.log('[SyncService] Device back online, checking connection...');
        if (!isConnected) {
          reconnectAttempts = 0;
          if (reconnectTimer) {
            clearTimeout(reconnectTimer);
            reconnectTimer = null;
          }
          syncService.connectRealtime();
        }
      });

      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible' && !isConnected) {
          console.log('[SyncService] App resumed/visible, reconnecting...');
          if (!isSubscribing) {
            syncService.connectRealtime();
          }
        }
      });
    }

    // 4. Initial async sync from database: pull orders and merge into local store
    void syncService.fetchRemoteOrders().then((remoteOrders) => {
      if (remoteOrders && remoteOrders.length > 0) {
        useOrderStore.getState().mergeRemoteOrders(remoteOrders);
      }
    });

    // 5. Also broadcast rider presence if current user is an online rider
    const currentUser = useAuthStore.getState().user;
    if (
      currentUser &&
      currentUser.role === 'rider' &&
      (currentUser as RiderProfile).availability === 'online'
    ) {
      syncService.broadcastRiderPresence(currentUser as RiderProfile);
    }
  },
};
